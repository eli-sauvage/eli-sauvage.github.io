class Ball {
    body: Matter.Body
    constraintpoint: Matter.Constraint
    constraintMouse: Matter.Constraint
    r: number
    distanceFromCenter = 400
    distanceConstraintFromCenter = 350
    constructor(angle: number) {
        let x = windowWidth / 2 + this.distanceFromCenter * cos(angle), y = windowHeight / 2 + this.distanceFromCenter * sin(angle)
        this.r = 100
        this.body = Bodies.circle(x, y, this.r)
        // Body.applyForce(this.ball, { x: 0, y: 0 }, { x: 0.5, y: 0*Math.random() * 0.01 })
        this.body.frictionAir = 0
        this.body.friction = 0
        this.body.frictionStatic = 0
        this.body.restitution = .8
        this.body.mass = 1
        this.constraintpoint = Matter.Constraint.create({
            bodyA: this.body,
            pointB: Matter.Vector.create(windowWidth / 2 + this.distanceConstraintFromCenter * cos(angle), windowHeight / 2 + this.distanceConstraintFromCenter * sin(angle)),
            length: 0,
            stiffness: .3
        })
        this.constraintMouse = Matter.Constraint.create({
            bodyA: this.body,
            pointB: { x: windowWidth / 2, y: windowHeight / 2 },
            length: 0,
            stiffness: 0.000000000001
        })

    }
    display(maskimage: p5.Graphics): void {
        let x = this.body.position.x, y = this.body.position.y
        if(dist(mouseX, mouseY, x, y) < this.r){
            maskimage.fill(255,255,255,50)
            maskimage.stroke(255, 255, 255, 50)
        }else{
            maskimage.fill(255,255,255, 255)
            maskimage.stroke(255, 255, 255, 255)

        }
        maskimage.circle(x, y, (this.r * 2))

    }
    update(): void {
        // if(dist(mouseX, mouseY, windowWidth/2, windowHeight/2) > 200)return
        let x = this.body.position.x, y = this.body.position.y
        // let force = Matter.Vector.normalise(Matter.Vector.create(mouseX-x, mouseY-y))
        // force = Matter.Vector.mult(force, -10)
        // Body.applyForce(this.body, {x:mouseX, y:mouseY}, force)
        this.constraintMouse.pointB = Matter.Vector.create(mouseX, mouseY)
        this.constraintMouse.stiffness = map(dist(mouseX, mouseY, x, y), 0, 1000, .01, .1)
    }
}