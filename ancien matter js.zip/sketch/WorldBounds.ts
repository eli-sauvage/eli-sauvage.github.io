class WorldBounds {
    bounds: Matter.Body[] = []
    constructor() {
        let w = windowWidth, h = windowHeight
        let thickness = 500
        this.bounds.push(Bodies.rectangle(w / 2, -thickness/2, w + 40, thickness))//top
        this.bounds.push(Bodies.rectangle(-thickness / 2, h / 2, thickness, h))//left
        this.bounds.push(Bodies.rectangle(w / 2, h + thickness / 2, w + 40, thickness))//bottom
        this.bounds.push(Bodies.rectangle(w + thickness / 2, h / 2, thickness, h))//right
        // this.bounds.push(Bodies.rectangle(0, 0, 200, 200))
        this.bounds.forEach(e => {
            Body.setStatic(e, true)
            e.restitution = 1
        })
    }
    getBounds(): Matter.Body[] {
        return this.bounds
    }
}