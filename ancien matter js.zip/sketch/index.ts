let { Engine, Composite, Bodies, Runner, Mouse, MouseConstraint, World, Body } = Matter
let engine: Matter.Engine,
    composite: Matter.Composite,
    world: Matter.World,
    mouseConstraint: Matter.MouseConstraint,
    balls: Ball[] = [],
    bounds: WorldBounds,
    begin:boolean = false,
    sourceImage:p5.Image,
    maskimage:p5.Graphics


function setup(): void {
    rectMode(CENTER)
    angleMode(RADIANS)
    let canvas = createCanvas(windowWidth, windowHeight),
        engine = Engine.create(),
        world = engine.world,
        mouse = Mouse.create(canvas.elt),
        mouseConstraint = MouseConstraint.create(engine, { mouse: mouse })
    sourceImage = loadImage("views/nodejs.png")
    sourceImage.resize(width, height)
    maskimage = createGraphics(width, height)
    engine.gravity = { x: 0, y: 0, scale: 1 }
    bounds = new WorldBounds()
    bounds.getBounds().forEach(e => Composite.add(world, e))
    Composite.add(world, mouseConstraint);

    for (let i = 0; i < 8; i++) {
        let a = map(i, 0, 8, 0, TWO_PI)
        let b = new Ball(a)
        balls.push(b)
        Composite.add(world, b.body)
        Composite.add(world, b.constraintpoint)
        Composite.add(world, b.constraintMouse)
    }
    // let b = new Ball(0)
    // balls.push(b)
    // Composite.add(world, b.body)
    // Composite.add(world, b.constraint)
    balls.forEach(b => b.update())
    console.log(mouseX)
    console.log(mouseY)
    Runner.run(engine)
    console.log(sourceImage.width, sourceImage.height)
}


function draw() {
    background(0)
    maskimage.clear(0,0,0,0)
    balls.forEach(e => {
        if(begin)e.display(maskimage)
        // circle(e.constraintpoint.pointB.x, e.constraintpoint.pointB.y, 10)
    })
    let img = sourceImage.get()
    img.resize(width, height)
    img.mask(maskimage.get())
    image(img, 0, 0)
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}
 
function mouseMoved(){
    begin=true
    balls.forEach(b=>b.update())
}
function mouseDragged(){
    begin=true
    balls.forEach(b=>b.update())
}
function mousePressed(){
    begin = true
    balls.forEach(b => b.update())
}