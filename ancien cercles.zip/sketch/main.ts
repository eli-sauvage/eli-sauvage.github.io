const nb = 8


let balls: Ball[] = [],
    sourceImage: p5.Image,
    maskimage: p5.Graphics,
    begin:boolean



function setup(): void {
    rectMode(CENTER)
    angleMode(RADIANS)
    let canvas = createCanvas(windowWidth, windowHeight)    
    sourceImage = loadImage("views/nodejs.png")
    sourceImage.resize(width, height)
    maskimage = createGraphics(width, height)

    for (let i = 0; i < nb; i++) {
        let a = map(i, 0, nb, 0, TWO_PI)
        let b = new Ball(a)
        balls.push(b)
    }
    // let b = new Ball(0)
    // balls.push(b)
    // Composite.add(world, b.body)
    // Composite.add(world, b.constraint)
    balls.forEach(b => b.update())
}


function draw() {
    background(0)
    maskimage.clear(0, 0, 0, 0)
    balls.forEach(e => {
        // if (!begin)return
        e.update()
        e.display(maskimage)
        // circle(e.constraintpoint.pointB.x, e.constraintpoint.pointB.y, 10)
    })
    if (frameRate() <30 ) console.log(frameRate())
    let img = sourceImage.get()
    img.resize(width, height)
    img.mask(maskimage.get())
    image(img, 0, 0)
    fill(255)
    text(Math.round(frameRate()), 20, 20)
}

function windowResized() {
    resizeCanvas(windowWidth, windowHeight);
}

// function mouseMoved() {
//     begin = true
//     // balls.forEach(b => b.update())
// }
// function mouseDragged() {
//     begin = true
//     balls.forEach(b => b.update())
// }
// function mousePressed() {
//     begin = true
//     balls.forEach(b => b.update())
// }