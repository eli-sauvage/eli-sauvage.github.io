class Ball {
    r: number
    distanceFromCenter = min(height/3, width/3)
    distanceConstraintFromCenter = 350
    mouseSpringForce: number = .001
    screenSpringForce: number = .001
    pos = createVector()
    center = createVector()
    constructor(angle: number) {
        this.pos.x = windowWidth / 2 + this.distanceFromCenter * cos(angle)
        this.pos.y = windowHeight / 2 + this.distanceFromCenter * sin(angle)
        this.center.x = this.pos.x, this.center.y = this.pos.y
        this.r = 10
    }
    display(maskimage: p5.Graphics): void {
        if (dist(mouseX, mouseY, this.pos.x, this.pos.y) < this.r) {
            maskimage.fill(255, 255, 255, 50)
            maskimage.stroke(255, 255, 255, 50)
        } else {
            maskimage.fill(255, 255, 255, 255)
            maskimage.stroke(255, 255, 255, 255)
        }
        maskimage.circle(this.pos.x, this.pos.y, (this.r * 2))
        maskimage.circle(this.center.x, this.center.y, 5)

    }
    update(): void {
        let relativeMousePos = createVector(mouseX - this.center.x, mouseY - this.center.y)
        relativeMousePos.mult(.22)
        // relativeMousePos.setMag(relativeMousePos.mag()**2)
        this.pos = this.center.copy().add(relativeMousePos)
    }
}